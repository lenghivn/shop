<?php
// Facebook Multi Page/Group Poster v3
// Created by Novartis (Safwan)

if ( count( get_included_files() ) == 1 )
    die();
return "<div id=token class='lightbox ui-widget-content'><center>
                      <form name=Account class='confirm' id=Account method=post action='?ucp'>
                      <h3 class='lightbox ui-widget-header'>" . $lang['Access Token'] . "</h3>
                      <br />
                      <textarea name=token id=userTokenValue class='textbox' rows=5>" . ( $hardDemo && ( $userName == "Multi" ) ? "*****" : $userToken ) . "</textarea><input type=hidden name='users'>
                      </table>
                      <input id=updateToken type=submit default value='" . $lang['Update'] . "' disabled> <input type=button value='" . $lang['OKay'] . "'  onclick=\"$('#token').trigger('close');\">
                      </form><br />
                      <strong>" . $lang['Get Token'] . "</strong><br /><table cols=3><tr><td>" . $lang['Step 1'] . " . " . $lang['Select'] . " " . $lang['Application'] . "<td>:<td>
                      <a href='https://www.facebook.com/v1.0/dialog/oauth/?app_id=41158896424&next=fbconnect%3A%2F%2Fsuccess&response_type=token&client_id=41158896424&state=YOUR_STATE_VALUE&scope=public_profile,user_photos,user_likes,user_managed_groups,user_groups,manage_pages,publish_pages,publish_actions' target='_new'><img src='https://fbcdn-photos-d-a.akamaihd.net/hphotos-ak-xfa1/t39.2080-0/851580_10151624509931425_2016153603_n.gif' title='HTC Sense'></a>
                      &nbsp;<a href='https://www.facebook.com/v1.0/dialog/oauth/?app_id=193278124048833&next=fbconnect%3A%2F%2Fsuccess&response_type=token&client_id=193278124048833&state=YOUR_STATE_VALUE&scope=public_profile,user_photos,user_likes,user_managed_groups,user_groups,manage_pages,publish_pages,publish_actions' target='_new'><img src='https://fbcdn-photos-a-a.akamaihd.net/hphotos-ak-xaf1/t39.2081-0/10173491_716190728424234_1087184338_n.png' title='HTC Sense 2'></a>
                      &nbsp;<a href='https://www.facebook.com/v1.0/dialog/oauth/?app_id=24553799497&next=http%3A%2F%2Fwww.facebook.com%2Fconnect%2Flogin_success.html&response_type=token&state=YOUR_STATE_VALUE&scope=public_profile,user_photos,user_likes,user_managed_groups,user_groups,manage_pages,publish_pages,publish_actions' target='_new'><img src='https://fbstatic-a.akamaihd.net/rsrc.php/v2/yE/r/7Sq7wKJHi_5.png' title='mobileblog'></a>
                      &nbsp;<a href='https://www.facebook.com/v1.0/dialog/oauth?redirect_uri=https%3A%2F%2Fwww.facebook.com%2Fconnect%2Flogin_success.html&scope=public_profile,user_photos,user_likes,user_managed_groups,user_groups,manage_pages,publish_pages,publish_actions&response_type=token&sso_key=com&client_id=10754253724&_rdr' target='_new'><img src='https://fbcdn-photos-c-a.akamaihd.net/hphotos-ak-xaf1/t39.2080-0/851556_10151474535983725_1160551704_n.gif' title='iPhoto'></a>
                      &nbsp;<a href='https://www.facebook.com/v1.0/dialog/oauth?redirect_uri=https%3A%2F%2Fwww.facebook.com%2Fconnect%2Flogin_success.html&scope=public_profile,user_photos,user_likes,user_managed_groups,user_groups,manage_pages,publish_pages,publish_actions&response_type=token&sso_key=com&client_id=145634995501895&_rdr' target='_new'><img src='https://fbcdn-photos-a-a.akamaihd.net/hphotos-ak-xaf1/t39.2081-0/851576_646264348772288_612357246_n.png' title='Graph API Explorer'></a>
                      <tr><td>" . $lang['Step 2'] . " . " . $lang['Access Token'] . "<td>:<td>
                      <a href='https://developers.facebook.com/tools/debug/accesstoken/?app_id=41158896424&version=v1.0' target='_new'><img src='https://fbcdn-photos-d-a.akamaihd.net/hphotos-ak-xfa1/t39.2080-0/851580_10151624509931425_2016153603_n.gif' title='HTC Sense'></a>
                      &nbsp;<a href='https://developers.facebook.com/tools/debug/accesstoken/?app_id=193278124048833&version=v1.0' target='_new'><img src='https://fbcdn-photos-a-a.akamaihd.net/hphotos-ak-xaf1/t39.2081-0/10173491_716190728424234_1087184338_n.png' title='HTC Sense 2'></a>
                      &nbsp;<a href='https://developers.facebook.com/tools/debug/accesstoken/?app_id=24553799497&version=v1.0' target='_new'><img src='https://fbstatic-a.akamaihd.net/rsrc.php/v2/yE/r/7Sq7wKJHi_5.png' title='mobileblog'></a>
                      &nbsp;<a href='https://developers.facebook.com/tools/debug/accesstoken/?app_id=10754253724&version=v1.0' target='_new'><img src='https://fbcdn-photos-c-a.akamaihd.net/hphotos-ak-xaf1/t39.2080-0/851556_10151474535983725_1160551704_n.gif' title='iPhoto'></a>
                      &nbsp;<a href='https://developers.facebook.com/tools/debug/accesstoken/?app_id=145634995501895&version=v1.0' target='_new'><img src='https://fbcdn-photos-a-a.akamaihd.net/hphotos-ak-xaf1/t39.2081-0/851576_646264348772288_612357246_n.png' title='Graph API Explorer'></a>
                      </table>
                      <br /><br /></center>
					  
                  </div>";
?>